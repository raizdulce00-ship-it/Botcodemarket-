package com.example.autoresponder

import java.text.Normalizer

const val FALLBACK_ID = "si_no_entiende"
const val AUDIO_ID = "cuando_mandan_un_audio"

const val CLOSE_ID = "cierre_del_chat"
const val NUDGE_ID = "recordatorio"
const val RETURN_ID = "cuando_vuelve_a_escribir"

fun isSpecial(id: String) =
    id == FALLBACK_ID || id == AUDIO_ID || id == CLOSE_ID || id == NUDGE_ID || id == RETURN_ID

const val DEFAULT_CLOSE_TEXT =
    "Quedo a disposición 🙌 Doy por finalizado el chat. Si necesitás algo más, escribime cuando quieras."
const val DEFAULT_NUDGE_TEXT =
    "¿Pudiste ver la información, {nombre}? 😊 Si necesitás algo más, escribime."
const val DEFAULT_RETURN_TEXT =
    "Hola de nuevo {nombre} 👋 Ya le aviso a una persona y te responde a la brevedad 🙌"

const val DEFAULT_AUDIO_TEXT =
    "Hola {nombre} 🎧 Por ahora no puedo escuchar audios. ¿Me lo podés escribir, por favor? 🙏"

/** ¿La notificación corresponde a una nota de voz / audio? */
fun looksLikeAudio(raw: String): Boolean {
    if (raw.contains("🎤") || raw.contains("🎙")) return true
    val n = norm(raw)
    return n.startsWith("mensaje de voz") || n.startsWith("nota de voz") ||
        n.startsWith("voice message") || n.startsWith("audio ")
}

data class Option(val key: String, val label: String, val target: String)
data class Node(
    val id: String, val name: String, val text: String,
    val triggers: List<String>, val options: List<Option>,
    val handoff: Boolean = false
)
class Script(val nodes: Map<String, Node>, val rootId: String)

/** Minúsculas, sin tildes ni símbolos/emojis: "¡Hola! 👋" -> "hola" */
fun norm(s: String): String {
    val d = Normalizer.normalize(s, Normalizer.Form.NFD)
    return d.replace(Regex("\\p{M}+"), "")
        .lowercase()
        .replace(Regex("[^a-z0-9]+"), " ")
        .trim()
}

fun slug(s: String): String = norm(s).replace(" ", "_")

/**
 * Formato de notas:
 *   PANTALLA: Nombre
 *   SI DICEN: palabra, otra palabra
 *   RESPONDER: texto (las líneas siguientes con 2 espacios continúan el texto)
 *   LINK: texto | https://...
 *   IMAGEN: https://...
 *   OPCION 1: Texto del botón -> Nombre de otra pantalla
 */
object Parser {
    fun parse(src: String): Script {
        val nodes = LinkedHashMap<String, Node>()
        var name: String? = null
        var triggers = ArrayList<String>()
        var options = ArrayList<Option>()
        var lines = ArrayList<String>()
        var pendingBlank = false
        var handoff = false

        fun close() {
            val n = name ?: return
            val id = slug(n)
            if (id.isNotEmpty()) {
                nodes[id] = Node(id, n, lines.joinToString("\n").trim(), triggers.toList(), options.toList(), handoff)
            }
        }
        fun add(x: String) {
            if (pendingBlank && lines.isNotEmpty()) lines.add("")
            pendingBlank = false
            lines.add(x)
        }

        for (raw in src.lines()) {
            val t = raw.trim()
            if (t.startsWith("//")) continue
            val colon = t.indexOf(':')
            val indented = raw.startsWith("  ") || raw.startsWith("\t")
            val label = if (colon > 0 && !indented) norm(t.substring(0, colon)) else ""
            val value = if (colon > 0) t.substring(colon + 1).trim() else ""
            when {
                label == "pantalla" || label == "regla" -> {
                    close()
                    name = value
                    triggers = ArrayList(); options = ArrayList(); lines = ArrayList()
                    pendingBlank = false
                    handoff = false
                }
                name == null -> {}
                label == "si dicen" || label == "cuando dicen" || label == "cuando" ->
                    value.split(",").map { norm(it) }.filter { it.isNotEmpty() }.forEach { triggers.add(it) }
                label == "pasar a persona" -> handoff = norm(value) == "si"
                label == "responder" || label == "respuesta" -> if (value.isNotEmpty()) add(value)
                label == "link" || label == "enlace" -> {
                    val p = value.split("|").map { it.trim() }
                    if (p.size >= 2 && p[0].isNotEmpty()) { add(p[0]); add(p[1]) }
                    else if (value.isNotEmpty()) add(value)
                }
                label == "imagen" || label == "foto" -> if (value.isNotEmpty()) add("📸 $value")
                label.startsWith("opcion") -> {
                    val key = label.removePrefix("opcion").trim().ifEmpty { (options.size + 1).toString() }
                    val v = value.replace("→", "->")
                    val arrow = v.lastIndexOf("->")
                    if (arrow > 0) {
                        val lab = v.substring(0, arrow).trim()
                        val tgt = v.substring(arrow + 2).trim()
                        if (lab.isNotEmpty() && tgt.isNotEmpty()) options.add(Option(key, lab, slug(tgt)))
                    }
                }
                t.isEmpty() -> pendingBlank = true
                else -> add(
                    if (indented) raw.substring(if (raw.startsWith("\t")) 1 else 2).trimEnd() else t
                )
            }
        }
        close()
        return Script(nodes, nodes.keys.firstOrNull() ?: "")
    }

    fun serialize(list: List<Node>): String {
        val names = list.associate { it.id to it.name }
        return buildString {
            for (n in list) {
                append("PANTALLA: ").append(n.name).append("\n")
                if (n.triggers.isNotEmpty()) append("SI DICEN: ").append(n.triggers.joinToString(", ")).append("\n")
                if (n.text.isNotBlank()) {
                    val ls = n.text.lines()
                    append("RESPONDER: ").append(ls[0]).append("\n")
                    for (x in ls.drop(1)) append("  ").append(x).append("\n")
                }
                if (n.handoff) append("PASAR A PERSONA: si\n")
                for (o in n.options) {
                    append("OPCION ").append(o.key).append(": ").append(o.label)
                        .append(" -> ").append(names[o.target] ?: o.target).append("\n")
                }
                append("\n")
            }
        }.trim() + "\n"
    }
}

object Store {
    fun load(prefs: Prefs): List<Node> = Parser.parse(prefs.script).nodes.values.toList()
    fun save(prefs: Prefs, list: List<Node>) { prefs.script = Parser.serialize(list) }

    /** Agrega las reglas especiales que todavía no existan. */
    fun ensureSpecials(prefs: Prefs) {
        val list = load(prefs).toMutableList()
        if (list.isEmpty()) return
        var changed = false
        fun need(id: String, name: String, text: String) {
            if (list.none { it.id == id }) {
                list.add(Node(id, name, text, emptyList(), emptyList()))
                changed = true
            }
        }
        need(AUDIO_ID, "Cuando mandan un audio", DEFAULT_AUDIO_TEXT)
        need(RETURN_ID, "Cuando vuelve a escribir", DEFAULT_RETURN_TEXT)
        need(NUDGE_ID, "Recordatorio", DEFAULT_NUDGE_TEXT)
        need(CLOSE_ID, "Cierre del chat", DEFAULT_CLOSE_TEXT)
        if (changed) save(prefs, list)
    }
}

class Session(var node: String, val stack: ArrayList<String>, var time: Long)

object Engine {
    private val sessions = HashMap<String, Session>()

    @Synchronized
    fun reset(contact: String) { sessions.remove(contact) }

    private fun matches(triggers: List<String>, m: String): Boolean {
        val words = m.split(" ")
        val padded = " $m "
        return triggers.any { t ->
            if (t.contains(' ')) padded.contains(" $t ") else words.any { it.startsWith(t) }
        }
    }

    private fun keycap(k: String): String =
        if (k.length == 1 && k[0].isDigit()) k + "\uFE0F\u20E3" else "$k)"

    private fun render(node: Node, script: Script, name: String): String {
        val sb = StringBuilder(node.text.replace("{nombre}", name))
        if (node.options.isNotEmpty()) {
            if (sb.isNotEmpty()) sb.append("\n\n")
            node.options.forEachIndexed { i, o ->
                if (i > 0) sb.append("\n")
                sb.append(keycap(o.key)).append(" ").append(o.label)
            }
        }
        if (node.id != script.rootId) {
            sb.append("\n\n0\uFE0F\u20E3 Volver · #\uFE0F\u20E3 Menú principal")
        }
        return sb.toString().trim()
    }

    /** ¿La conversación quedó en una pantalla que pasa el chat a una persona? */
    @Synchronized
    fun isHandoff(contact: String, script: Script): Boolean {
        val s = sessions[contact] ?: return false
        return script.nodes[s.node]?.handoff == true
    }

    /** Texto a responder, o null si no hay que responder. */
    @Synchronized
    fun reply(contact: String, name: String, message: String, script: Script, sessionMs: Long): String? {
        if (script.nodes.isEmpty()) return null
        val raw = message.trim()
        val m = norm(raw)
        val goRoot = raw.startsWith("#")

        // Audios: no se pueden escuchar; se responde con la regla de audios
        if (looksLikeAudio(raw)) {
            val a = script.nodes[AUDIO_ID]
            if (a != null && a.text.isNotBlank()) return a.text.replace("{nombre}", name)
        }
        if (m.isEmpty() && !goRoot) return null // solo emojis / stickers

        val now = System.currentTimeMillis()
        val root = script.rootId
        val existing = sessions[contact]?.takeIf { now - it.time <= sessionMs }
        val sess: Session
        var unknown = false

        if (existing == null) {
            val hit = if (goRoot) root
            else script.nodes.values.firstOrNull { !isSpecial(it.id) && matches(it.triggers, m) }?.id
            sess = Session(hit ?: root, ArrayList(), now)
            sessions[contact] = sess
        } else {
            sess = existing
            val cur = script.nodes[sess.node]
            val opt = cur?.options?.firstOrNull { norm(it.key) == m || norm(it.label) == m }
            when {
                goRoot -> { sess.stack.clear(); sess.node = root }
                (m == "0" || m == "volver" || m == "atras") && sess.node != root ->
                    sess.node = if (sess.stack.isEmpty()) root else sess.stack.removeAt(sess.stack.size - 1)
                opt != null && script.nodes.containsKey(opt.target) -> {
                    sess.stack.add(sess.node)
                    sess.node = opt.target
                }
                else -> {
                    val t = script.nodes.values.firstOrNull { !isSpecial(it.id) && matches(it.triggers, m) }
                    if (t != null) {
                        sess.stack.clear()
                        if (t.id != root) sess.stack.add(root)
                        sess.node = t.id
                    } else unknown = true
                }
            }
            sess.time = now
        }

        val node = script.nodes[sess.node] ?: script.nodes[root] ?: return null
        val body = render(node, script, name)
        if (!unknown) return body
        val fb = script.nodes[FALLBACK_ID]?.text?.takeIf { it.isNotBlank() }
            ?: "No entendí tu mensaje 😅 Probá con una de estas opciones:"
        return fb.replace("{nombre}", name) + "\n\n" + body
    }
}

/** Lista de contactos guardada como líneas "Nombre|dígitos". */
object ContactList {
    fun parse(s: String): List<Pair<String, String>> =
        s.lines().filter { it.isNotBlank() }.map {
            val p = it.split("|")
            Pair(p[0].trim(), p.getOrElse(1) { "" }.filter { c -> c.isDigit() })
        }

    fun add(s: String, name: String, digits: String): String {
        val entry = name.trim() + "|" + digits
        if (parse(s).any { it.first == name.trim() && it.second == digits }) return s
        return (s.trim() + "\n" + entry).trim()
    }

    fun removeAt(s: String, index: Int): String {
        val lines = s.lines().filter { it.isNotBlank() }.toMutableList()
        if (index in lines.indices) lines.removeAt(index)
        return lines.joinToString("\n")
    }

    fun label(e: Pair<String, String>): String =
        if (e.first.isNotEmpty()) e.first else "+" + e.second

    /** ¿El título de la notificación corresponde a alguien de la lista? */
    fun matches(list: String, title: String): Boolean {
        val tWords = norm(title).split(" ").filter { it.isNotEmpty() }
        val tDigits = title.filter { it.isDigit() }
        return parse(list).any { (n, d) ->
            val nWords = norm(n).split(" ").filter { it.isNotEmpty() }
            (nWords.isNotEmpty() && nWords.all { it in tWords }) ||
                (d.length >= 6 && tDigits.length >= 6 && d.takeLast(8) == tDigits.takeLast(8))
        }
    }
}
