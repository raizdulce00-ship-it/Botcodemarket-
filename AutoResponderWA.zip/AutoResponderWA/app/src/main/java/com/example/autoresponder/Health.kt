package com.example.autoresponder

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.BroadcastReceiver
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import android.provider.Settings
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object Health {
    fun listenerGranted(ctx: Context): Boolean =
        Settings.Secure.getString(ctx.contentResolver, "enabled_notification_listeners")
            ?.contains(ctx.packageName) == true

    fun batteryOk(ctx: Context): Boolean {
        val pm = ctx.getSystemService(Context.POWER_SERVICE) as PowerManager
        return pm.isIgnoringBatteryOptimizations(ctx.packageName)
    }

    fun startKeepAlive(ctx: Context) {
        try { ctx.startForegroundService(Intent(ctx, KeepAliveService::class.java)) } catch (e: Exception) { }
    }

    fun stopKeepAlive(ctx: Context) {
        try { ctx.stopService(Intent(ctx, KeepAliveService::class.java)) } catch (e: Exception) { }
    }

    /** Apagar y prender el servicio de notificaciones fuerza a Android a reconectarlo. */
    fun toggleComponent(ctx: Context) {
        try {
            val pm = ctx.packageManager
            val cn = ComponentName(ctx, WhatsAppReplyService::class.java)
            pm.setComponentEnabledSetting(cn, PackageManager.COMPONENT_ENABLED_STATE_DISABLED, PackageManager.DONT_KILL_APP)
            pm.setComponentEnabledSetting(cn, PackageManager.COMPONENT_ENABLED_STATE_ENABLED, PackageManager.DONT_KILL_APP)
        } catch (e: Exception) { }
    }
}

/** Registro simple de lo que hace la app (se guarda solo en el celular). */
object ActivityLog {
    @Synchronized
    fun add(ctx: Context, text: String) {
        val sp = ctx.getSharedPreferences("log", Context.MODE_PRIVATE)
        val t = SimpleDateFormat("dd/MM HH:mm:ss", Locale.getDefault()).format(Date())
        val cur = sp.getString("log", "") ?: ""
        sp.edit().putString("log", (cur + t + "  " + text + "\n").takeLast(6000)).apply()
    }

    fun read(ctx: Context): String =
        ctx.getSharedPreferences("log", Context.MODE_PRIVATE).getString("log", "") ?: ""

    fun clear(ctx: Context) {
        ctx.getSharedPreferences("log", Context.MODE_PRIVATE).edit().putString("log", "").apply()
    }
}

/** Servicio con notificación fija: evita que el sistema cierre la app y revisa la conexión. */
class KeepAliveService : Service() {
    private val handler = Handler(Looper.getMainLooper())
    private var misses = 0

    private val loop = object : Runnable {
        override fun run() {
            val ctx = this@KeepAliveService
            val prefs = Prefs(ctx)
            if (!prefs.enabled || !prefs.keepAlive) { stopSelf(); return }
            if (Health.listenerGranted(ctx) && !WhatsAppReplyService.connected) {
                misses++
                WhatsAppReplyService.rebind(ctx)
                if (misses >= 3) {
                    Health.toggleComponent(ctx)
                    ActivityLog.add(ctx, "Reconexión forzada")
                    misses = 0
                }
            } else misses = 0
            handler.postDelayed(this, 60_000L)
        }
    }

    override fun onCreate() {
        super.onCreate()
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(
            NotificationChannel("keepalive", "botcodemarket activo", NotificationManager.IMPORTANCE_LOW)
        )
        val pi = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )
        val n = Notification.Builder(this, "keepalive")
            .setContentTitle("botcodemarket activo")
            .setContentText("Respondiendo mensajes automáticamente")
            .setSmallIcon(android.R.drawable.stat_notify_chat)
            .setContentIntent(pi)
            .setOngoing(true)
            .build()
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(1, n)
        }
        handler.post(loop)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int = START_STICKY

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}

/** Al prender el celular o actualizar la app: reconectar y volver a arrancar. */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, intent: Intent) {
        val prefs = Prefs(ctx)
        if (!prefs.enabled) return
        WhatsAppReplyService.rebind(ctx)
        if (prefs.keepAlive) Health.startKeepAlive(ctx)
    }
}
