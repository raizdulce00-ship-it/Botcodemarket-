package com.example.autoresponder

import android.app.Activity
import android.app.AlertDialog
import android.os.Bundle
import android.text.InputType
import android.view.Gravity
import android.view.ViewGroup
import android.widget.*

class NodeEditActivity : Activity() {

    private lateinit var prefs: Prefs
    private var nodes: List<Node> = emptyList()
    private var origId: String? = null
    private var targets: List<Node> = emptyList()
    private val optRows = ArrayList<Pair<EditText, Spinner>>()
    private lateinit var optBox: LinearLayout
    private lateinit var nameEt: EditText
    private lateinit var trigEt: EditText
    private lateinit var textEt: EditText
    private lateinit var mainCb: CheckBox
    private lateinit var handoffCb: CheckBox

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = Prefs(this)
        nodes = Store.load(prefs)
        origId = intent.getStringExtra("id")
        val cur = nodes.firstOrNull { it.id == origId }
        val isFallback = cur != null && isSpecial(cur.id)
        targets = nodes.filter { !isSpecial(it.id) && it.id != origId }
        title = if (cur == null) "Nueva regla" else "Editar regla"

        val col = Ui.page(this)

        col.addView(Ui.title(this, "Nombre de la regla"))
        nameEt = EditText(this)
        nameEt.hint = "Ej: Precios"
        nameEt.setText(cur?.name ?: "")
        nameEt.isEnabled = !isFallback
        col.addView(nameEt)

        trigEt = EditText(this)
        trigEt.hint = "Ej: precio, cuanto sale, valor"
        trigEt.setText(cur?.triggers?.joinToString(", ") ?: "")
        if (!isFallback) {
            col.addView(Ui.title(this, "Si el cliente escribe…"))
            col.addView(Ui.note(this, "Palabras que activan esta regla, separadas por coma. No importan mayúsculas ni tildes."))
            col.addView(trigEt)
        }

        col.addView(Ui.title(this, "Qué le respondo"))
        textEt = EditText(this)
        textEt.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE
        textEt.minLines = 5
        textEt.gravity = Gravity.TOP
        textEt.setText(cur?.text ?: "")
        val bar = LinearLayout(this)
        fun tool(t: String, f: () -> Unit) {
            val b = Ui.btn(this, t, f)
            b.textSize = 12f
            b.layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
            bar.addView(b)
        }
        tool("😀 Emoji") { Ui.emojiPicker(this) { insert(it) } }
        tool("🔗 Link") { linkDialog() }
        tool("🖼️ Imagen") { imageDialog() }
        tool("👤 Nombre") { insert("{nombre}") }
        col.addView(bar)
        col.addView(textEt)

        if (!isFallback) {
            col.addView(Ui.title(this, "Botones del menú (opcional)"))
            col.addView(Ui.note(this, "El cliente elige con un número. Elegí a qué regla lleva cada uno " +
                "o dejá \"Crear regla nueva\" y la creo por vos."))
            optBox = LinearLayout(this)
            optBox.orientation = LinearLayout.VERTICAL
            col.addView(optBox)
            cur?.options?.forEach { addOptRow(it.label, it.target) }
            col.addView(Ui.btn(this, "➕ Agregar opción") { addOptRow("", "") })
        }

        mainCb = CheckBox(this)
        mainCb.text = "Es el menú principal (lo primero que ve el cliente)"
        val isRoot = cur != null && nodes.firstOrNull()?.id == cur.id
        mainCb.isChecked = isRoot
        mainCb.isEnabled = !isRoot && !isFallback
        if (!isFallback) col.addView(mainCb)

        handoffCb = CheckBox(this)
        handoffCb.text = "Pasa la charla a una persona (el bot deja de responder a este cliente)"
        handoffCb.isChecked = cur?.handoff == true
        if (!isFallback) col.addView(handoffCb)

        col.addView(Ui.btn(this, "✅ Guardar") { save() })
        if (cur != null && nodes.size > 1) {
            col.addView(Ui.btn(this, "🗑️ Eliminar esta regla") { confirmDelete() })
        }
    }

    private fun insert(s: String) {
        val pos = textEt.selectionStart.coerceAtLeast(0)
        textEt.text.insert(pos, s)
    }

    private fun dialogBox(): LinearLayout {
        val pad = Ui.dp(this, 16)
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(pad, pad, pad, pad)
        return box
    }

    private fun linkDialog() {
        val box = dialogBox()
        val labelEt = EditText(this)
        labelEt.hint = "Texto (opcional). Ej: Reservá tu turno"
        val urlEt = EditText(this)
        urlEt.hint = "https://..."
        box.addView(labelEt)
        box.addView(urlEt)
        AlertDialog.Builder(this).setTitle("Agregar link").setView(box)
            .setPositiveButton("Agregar") { _, _ ->
                val u = urlEt.text.toString().trim()
                val l = labelEt.text.toString().trim()
                if (u.isNotEmpty()) insert("\n" + (if (l.isNotEmpty()) "$l\n" else "") + u + "\n")
            }
            .setNegativeButton("Cancelar", null).show()
    }

    private fun imageDialog() {
        val box = dialogBox()
        box.addView(TextView(this).also {
            it.text = "Pegá el link de la imagen (https://...jpg). WhatsApp la muestra como " +
                "vista previa del link: desde una respuesta automática no se puede adjuntar la foto."
            it.textSize = 13f
        })
        val urlEt = EditText(this)
        urlEt.hint = "https://.../foto.jpg"
        box.addView(urlEt)
        AlertDialog.Builder(this).setTitle("Agregar imagen").setView(box)
            .setPositiveButton("Agregar") { _, _ ->
                val u = urlEt.text.toString().trim()
                if (u.isNotEmpty()) insert("\n📸 $u\n")
            }
            .setNegativeButton("Cancelar", null).show()
    }

    private fun addOptRow(label: String, targetId: String) {
        val row = LinearLayout(this)
        row.orientation = LinearLayout.VERTICAL
        row.setPadding(0, Ui.dp(this, 8), 0, Ui.dp(this, 8))
        val et = EditText(this)
        et.hint = "Texto del botón. Ej: Precios 💲"
        et.setText(label)
        val line = LinearLayout(this)
        val sp = Spinner(this)
        val names = listOf("➕ Crear regla nueva") + targets.map { it.name }
        sp.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, names)
        sp.setSelection(targets.indexOfFirst { it.id == targetId } + 1)
        sp.layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        val pair = Pair(et, sp)
        val del = Ui.btn(this, "✕") {
            optBox.removeView(row)
            optRows.remove(pair)
        }
        line.addView(sp)
        line.addView(del)
        row.addView(et)
        row.addView(line)
        optRows.add(pair)
        optBox.addView(row)
    }

    private fun save() {
        val name = nameEt.text.toString().trim()
        val id = slug(name)
        if (id.isEmpty()) { Ui.toast(this, "Poné un nombre para la regla"); return }
        if (nodes.any { it.id == id && it.id != origId }) {
            Ui.toast(this, "Ya existe una regla con ese nombre"); return
        }
        val triggers = trigEt.text.toString().split(",").map { norm(it) }.filter { it.isNotEmpty() }
        val list: MutableList<Node> = nodes.map { n ->
            if (origId != null && origId != id)
                n.copy(options = n.options.map { o -> if (o.target == origId) o.copy(target = id) else o })
            else n
        }.toMutableList()

        val created = ArrayList<Node>()
        val options = ArrayList<Option>()
        if (origId?.let { isSpecial(it) } != true) {
            for ((et, sp) in optRows) {
                val label = et.text.toString().trim()
                if (label.isEmpty()) continue
                val pos = sp.selectedItemPosition
                val target: String
                if (pos > 0) {
                    target = targets[pos - 1].id
                } else {
                    val nid = slug(label)
                    if (nid.isEmpty() || nid == id) continue
                    if (list.none { it.id == nid } && created.none { it.id == nid }) {
                        created.add(Node(nid, label, "", emptyList(), emptyList()))
                    }
                    target = nid
                }
                options.add(Option((options.size + 1).toString(), label, target))
            }
        }

        val node = Node(id, name, textEt.text.toString().trim(), triggers, options, handoffCb.isChecked)
        val idx = list.indexOfFirst { it.id == (origId ?: id) }
        if (idx >= 0) list[idx] = node else list.add(node)
        list.addAll(created)
        if (mainCb.isChecked && list.first().id != id) {
            list.removeAll { it.id == id }
            list.add(0, node)
        }
        Store.save(prefs, list)
        if (created.isNotEmpty()) {
            Ui.toast(this, "Creé ${created.size} regla(s) nueva(s): completalas en la lista")
        } else Ui.toast(this, "Guardado")
        finish()
    }

    private fun confirmDelete() {
        AlertDialog.Builder(this).setTitle("¿Eliminar esta regla?")
            .setMessage("También se quitan los botones que llevaban a ella.")
            .setPositiveButton("Eliminar") { _, _ ->
                val left = nodes.filter { it.id != origId }.map { n ->
                    n.copy(options = n.options.filter { it.target != origId }
                        .mapIndexed { i, o -> o.copy(key = (i + 1).toString()) })
                }
                Store.save(prefs, left)
                finish()
            }
            .setNegativeButton("Cancelar", null).show()
    }
}
