package com.example.autoresponder

import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.graphics.Typeface
import android.view.ViewGroup
import android.widget.*

object Ui {
    fun dp(c: Context, v: Int) = (v * c.resources.displayMetrics.density).toInt()

    fun page(a: Activity): LinearLayout {
        val pad = dp(a, 16)
        val col = LinearLayout(a).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad, pad, pad)
        }
        a.setContentView(ScrollView(a).apply {
            addView(col, ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        })
        return col
    }

    fun title(c: Context, t: String) = TextView(c).apply {
        text = t
        textSize = 17f
        setTypeface(null, Typeface.BOLD)
        setPadding(0, dp(c, 18), 0, dp(c, 4))
    }

    fun note(c: Context, t: String) = TextView(c).apply {
        text = t
        textSize = 13f
        setTextColor(0xFF666666.toInt())
        setPadding(0, 0, 0, dp(c, 6))
    }

    fun btn(c: Context, t: String, onClick: () -> Unit) = Button(c).apply {
        text = t
        isAllCaps = false
        setOnClickListener { onClick() }
    }

    private val EMOJIS = listOf(
        "😀", "😃", "😄", "😁", "😊", "😍", "🥰", "😘", "😎", "🤗", "🙂", "😉",
        "👍", "👏", "🙌", "🙏", "💪", "🔥", "✨", "⭐", "❤️", "💙", "💚", "🎉",
        "🎁", "📅", "🕒", "📍", "📞", "💬", "📸", "🖼️", "🛍️", "🛒", "💲", "💰",
        "🚚", "📦", "✅", "❌", "⚠️", "👉", "👇", "👋", "🙋", "😅", "🤔", "🍓",
        "🌿", "☕", "🍰", "🏠", "🔧", "✂️", "💇", "🩺", "🚗", "📝", "📢", "🆕"
    )

    fun emojiPicker(a: Activity, onPick: (String) -> Unit) {
        val grid = GridLayout(a).apply { columnCount = 6 }
        for (e in EMOJIS) {
            grid.addView(TextView(a).apply {
                text = e
                textSize = 26f
                setPadding(dp(a, 10), dp(a, 8), dp(a, 10), dp(a, 8))
                setOnClickListener { onPick(e) }
            })
        }
        AlertDialog.Builder(a).setTitle("Elegí un emoji")
            .setView(ScrollView(a).apply { addView(grid) })
            .setNegativeButton("Cerrar", null).show()
    }

    fun toast(c: Context, t: String) = Toast.makeText(c, t, Toast.LENGTH_SHORT).show()
}
