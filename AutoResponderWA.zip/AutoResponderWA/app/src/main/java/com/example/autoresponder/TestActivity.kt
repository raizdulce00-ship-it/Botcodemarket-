package com.example.autoresponder

import android.app.Activity
import android.os.Bundle
import android.widget.*

class TestActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        title = "Probar"
        val prefs = Prefs(this)
        val col = Ui.page(this)
        col.addView(Ui.note(this, "Escribí como si fueras el cliente. Así ves cómo responde, sin usar WhatsApp."))

        val out = TextView(this)
        out.setTextIsSelectable(true)
        out.textSize = 15f
        val et = EditText(this)
        et.hint = "Mensaje del cliente"
        col.addView(et)
        col.addView(Ui.btn(this, "Enviar") {
            val msg = et.text.toString()
            if (msg.isNotBlank()) {
                val r = Engine.reply("__sim__", "Cliente", msg, Parser.parse(prefs.script), 30 * 60_000L)
                out.text = "Cliente: $msg\n\nAutorespondedor:\n${r?.let { prefs.decorate(it) } ?: "(no respondería)"}\n\n" + "────────\n\n" + out.text
                et.setText("")
            }
        })
        col.addView(Ui.btn(this, "Reiniciar conversación") {
            Engine.reset("__sim__")
            out.text = ""
        })
        col.addView(out)
    }
}
