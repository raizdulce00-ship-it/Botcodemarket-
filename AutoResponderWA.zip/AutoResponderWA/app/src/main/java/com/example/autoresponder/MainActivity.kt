package com.example.autoresponder

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.ComponentName
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.text.Editable
import android.text.InputType
import android.text.TextWatcher
import android.widget.*

class MainActivity : Activity() {

    private lateinit var statusTv: TextView
    private lateinit var prefs: Prefs

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        title = "botcodemarket"
        prefs = Prefs(this)
        Store.ensureSpecials(prefs)

        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        }

        val col = Ui.page(this)

        val sw = Switch(this)
        sw.text = "Respuestas automáticas"
        sw.textSize = 18f
        sw.isChecked = prefs.enabled
        sw.setOnCheckedChangeListener { _, c ->
            prefs.enabled = c
            if (c) {
                WhatsAppReplyService.rebind(this)
                if (prefs.keepAlive) Health.startKeepAlive(this)
            } else {
                Health.stopKeepAlive(this)
            }
        }
        col.addView(sw)

        statusTv = TextView(this)
        statusTv.setPadding(0, Ui.dp(this, 8), 0, Ui.dp(this, 8))
        col.addView(statusTv)

        col.addView(Ui.btn(this, "🔔 Dar permiso de notificaciones") {
            startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
        })
        col.addView(Ui.btn(this, "🔋 Batería: permitir sin restricciones") { askBattery() })
        col.addView(Ui.btn(this, "🛡️ Que no se desconecte (inicio automático)") { keepAliveHelp() })
        col.addView(Ui.btn(this, "🔄 Reconectar ahora") {
            WhatsAppReplyService.rebind(this)
            Health.toggleComponent(this)
            if (prefs.enabled && prefs.keepAlive) Health.startKeepAlive(this)
            Ui.toast(this, "Reconectando…")
        })

        col.addView(Ui.title(this, "¿En qué app responder?"))
        val wa = CheckBox(this)
        wa.text = "WhatsApp"
        wa.isChecked = prefs.useWa
        wa.setOnCheckedChangeListener { _, c -> prefs.useWa = c }
        val biz = CheckBox(this)
        biz.text = "WhatsApp Business"
        biz.isChecked = prefs.useBiz
        biz.setOnCheckedChangeListener { _, c -> prefs.useBiz = c }
        col.addView(wa)
        col.addView(biz)

        col.addView(Ui.title(this, "Encabezado de los mensajes"))
        val hCb = CheckBox(this)
        hCb.text = "Mostrar un encabezado arriba de cada mensaje"
        hCb.isChecked = prefs.headerOn
        val hEt = EditText(this)
        hEt.hint = "Ej: BOTCodeMarket"
        hEt.setText(prefs.header)
        hEt.isEnabled = prefs.headerOn
        hCb.setOnCheckedChangeListener { _, c -> prefs.headerOn = c; hEt.isEnabled = c }
        hEt.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable?) { prefs.header = s?.toString() ?: "" }
            override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
            override fun onTextChanged(s: CharSequence?, st: Int, b: Int, c: Int) {}
        })
        col.addView(hCb)
        col.addView(hEt)
        col.addView(Ui.note(this, "Se envía en negrita. Podés cambiarlo por el nombre de tu negocio."))

        col.addView(Ui.title(this, "Qué responder"))
        col.addView(Ui.btn(this, "💬 Mensajes y menús") {
            startActivity(Intent(this, RulesActivity::class.java))
        })
        col.addView(Ui.btn(this, "🚫 Contactos (a quién sí / a quién no)") {
            startActivity(Intent(this, ContactsActivity::class.java))
        })
        col.addView(Ui.btn(this, "📝 Cargar reglas en formato notas") {
            startActivity(Intent(this, NotesActivity::class.java))
        })
        col.addView(Ui.btn(this, "🧪 Probar cómo responde") {
            startActivity(Intent(this, TestActivity::class.java))
        })
        col.addView(Ui.btn(this, "⚙️ Ajustes (cierre del chat, recordatorio, horario)") { settingsDialog() })
        col.addView(Ui.btn(this, "📜 Registro de actividad") { logDialog() })
    }

    override fun onResume() {
        super.onResume()
        val granted = Health.listenerGranted(this)
        val conn = WhatsAppReplyService.connected
        val batt = Health.batteryOk(this)
        statusTv.text = buildString {
            append(if (granted) "✅" else "❌").append(" Permiso de notificaciones\n")
            append(if (conn) "✅" else "⚠️").append(" Conexión con WhatsApp: ")
                .append(if (conn) "activa" else "desconectada (tocá Reconectar)").append("\n")
            append(if (batt) "✅" else "❌").append(" Batería sin restricciones")
        }
        if (prefs.enabled && prefs.keepAlive) Health.startKeepAlive(this)
        if (prefs.enabled && granted && !conn) WhatsAppReplyService.rebind(this)
    }

    private fun askBattery() {
        try {
            startActivity(Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS,
                Uri.parse("package:$packageName")))
        } catch (e: Exception) {
            try { startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)) }
            catch (e2: Exception) { openAppSettings() }
        }
    }

    private fun openAppSettings() {
        startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
            Uri.parse("package:$packageName")))
    }

    private fun keepAliveHelp() {
        val tips = "Para que Android no cierre la app:\n\n" +
            "1) Batería → permitir \"sin restricciones\" (botón 🔋).\n\n" +
            "2) Xiaomi / Redmi / Poco: Ajustes → Aplicaciones → Permisos → Inicio automático → " +
            "activá botcodemarket. En Ajustes → Batería → botcodemarket → \"Sin restricciones\".\n\n" +
            "3) Samsung: Batería → Límites de uso en segundo plano → sacá la app de \"Apps en suspensión\".\n\n" +
            "4) Abrí Recientes, mantené apretada la tarjeta de la app y tocá el candado 🔒.\n\n" +
            "5) No la cierres deslizando desde Recientes."
        AlertDialog.Builder(this).setTitle("Que no se desconecte").setMessage(tips)
            .setPositiveButton("Ajustes de la app") { _, _ -> openAppSettings() }
            .setNeutralButton("Inicio automático (Xiaomi)") { _, _ ->
                try {
                    startActivity(Intent().setComponent(ComponentName(
                        "com.miui.securitycenter",
                        "com.miui.permcenter.autostart.AutoStartManagementActivity")))
                } catch (e: Exception) { openAppSettings() }
            }
            .setNegativeButton("Cerrar", null).show()
    }

    private fun logDialog() {
        val tv = TextView(this)
        tv.text = ActivityLog.read(this).ifBlank { "(todavía no hay actividad)" }
        tv.setTextIsSelectable(true)
        tv.textSize = 12f
        val p = Ui.dp(this, 16)
        tv.setPadding(p, p, p, p)
        AlertDialog.Builder(this).setTitle("Registro de actividad")
            .setView(ScrollView(this).also { it.addView(tv) })
            .setPositiveButton("OK", null)
            .setNeutralButton("Borrar") { _, _ -> ActivityLog.clear(this) }
            .show()
    }

    private fun settingsDialog() {
        val pad = Ui.dp(this, 16)
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(pad, pad, pad, pad)
        fun field(label: String, v: Int): EditText {
            box.addView(TextView(this).also { it.text = label })
            val et = EditText(this)
            et.setText(v.toString())
            et.inputType = InputType.TYPE_CLASS_NUMBER
            box.addView(et)
            return et
        }
        fun check(label: String, v: Boolean): CheckBox {
            val c = CheckBox(this)
            c.text = label
            c.isChecked = v
            box.addView(c)
            return c
        }
        val sec = field("Segundos de espera entre respuestas al mismo contacto", prefs.minSeconds)
        val close = field("Minutos sin respuesta del cliente para cerrar el chat (recomendado 30)", prefs.sessionMin)
        val nudgeCb = check("Enviar un recordatorio si el cliente no responde", prefs.nudgeOn)
        val nudge = field("Minutos para el recordatorio (menor que el cierre)", prefs.nudgeMin)
        val humanCb = check("Dejar de responder cuando yo abro o atiendo el chat", prefs.pauseOnHuman)
        val keepCb = check("Mantener la app siempre activa (notificación fija)", prefs.keepAlive)
        val from = field("Responder desde la hora (0-23)", prefs.hourFrom)
        val to = field("hasta la hora (0-23). Si son iguales, responde todo el día", prefs.hourTo)
        AlertDialog.Builder(this).setTitle("Ajustes")
            .setView(ScrollView(this).also { it.addView(box) })
            .setPositiveButton("Guardar") { _, _ ->
                prefs.minSeconds = (sec.text.toString().toIntOrNull() ?: 2).coerceAtLeast(0)
                prefs.sessionMin = (close.text.toString().toIntOrNull() ?: 30).coerceAtLeast(1)
                prefs.nudgeOn = nudgeCb.isChecked
                prefs.nudgeMin = (nudge.text.toString().toIntOrNull() ?: 15).coerceAtLeast(1)
                prefs.pauseOnHuman = humanCb.isChecked
                prefs.keepAlive = keepCb.isChecked
                prefs.hourFrom = (from.text.toString().toIntOrNull() ?: 0).coerceIn(0, 23)
                prefs.hourTo = (to.text.toString().toIntOrNull() ?: 0).coerceIn(0, 23)
                if (prefs.enabled && prefs.keepAlive) Health.startKeepAlive(this)
                if (!prefs.keepAlive) Health.stopKeepAlive(this)
            }
            .setNegativeButton("Cancelar", null).show()
    }
}
