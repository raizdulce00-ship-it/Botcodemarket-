package com.example.autoresponder

import android.app.Notification
import android.app.PendingIntent
import android.app.RemoteInput
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import java.util.Calendar
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.CopyOnWriteArrayList

class WhatsAppReplyService : NotificationListenerService() {

    companion object {
        @Volatile var connected = false

        fun rebind(ctx: Context) {
            try {
                NotificationListenerService.requestRebind(
                    ComponentName(ctx, WhatsAppReplyService::class.java)
                )
            } catch (e: Exception) { }
        }
    }

    /** Estado de la conversación con un contacto.
     *  phase: 0 = menú, 1 = esperando a una persona, 2 = chat cerrado, 3 = atendido por una persona */
    private class Conv(val key: String) {
        var title = ""
        var phase = 0
        var lastCustomerAt = 0L
        var lastBotAt = 0L
        var nudged = false
        var action: Notification.Action? = null
    }

    private val pkgs = setOf("com.whatsapp", "com.whatsapp.w4b")
    private val convs = ConcurrentHashMap<String, Conv>()
    private val lastSent = ConcurrentHashMap<String, Long>()
    private val lastSentNorm = ConcurrentHashMap<String, String>()
    private val lastMsgTime = ConcurrentHashMap<String, Long>()
    private val lastText = ConcurrentHashMap<String, String>()
    private val lastTextAt = ConcurrentHashMap<String, Long>()
    private val recentSent = CopyOnWriteArrayList<Pair<String, Long>>()

    private val handler = Handler(Looper.getMainLooper())
    private val tick = object : Runnable {
        override fun run() {
            try { checkConvos() } catch (e: Exception) { }
            handler.postDelayed(this, 30_000L)
        }
    }

    override fun onListenerConnected() {
        connected = true
        handler.removeCallbacks(tick)
        handler.postDelayed(tick, 30_000L)
        ActivityLog.add(this, "Conectado a las notificaciones")
        val prefs = Prefs(this)
        if (prefs.enabled && prefs.keepAlive) Health.startKeepAlive(this)
    }

    override fun onListenerDisconnected() {
        connected = false
        handler.removeCallbacks(tick)
        ActivityLog.add(this, "Se desconectó: reconectando")
        if (Health.listenerGranted(this) && Prefs(this).enabled) rebind(this)
    }

    private fun replyAction(n: Notification): Notification.Action? {
        val actions = (n.actions?.toList().orEmpty()) + Notification.WearableExtender(n).actions
        return actions.firstOrNull { it.remoteInputs?.isNotEmpty() == true }
    }

    @Suppress("DEPRECATION")
    override fun onNotificationPosted(sbn: StatusBarNotification) {
        val prefs = Prefs(this)
        if (!prefs.enabled) return
        val okPkg = (sbn.packageName == "com.whatsapp" && prefs.useWa) ||
            (sbn.packageName == "com.whatsapp.w4b" && prefs.useBiz)
        if (!okPkg) return

        val n = sbn.notification
        if (n.flags and Notification.FLAG_GROUP_SUMMARY != 0) return
        val extras = n.extras
        if (extras.getBoolean("android.isGroupConversation")) return // ignora grupos

        val title = extras.getString(Notification.EXTRA_TITLE) ?: return
        if (title == "WhatsApp" || title == "WhatsApp Business") return

        // Último mensaje de la conversación
        var text: String? = null
        var msgTime = 0L
        val last = extras.getParcelableArray(Notification.EXTRA_MESSAGES)?.lastOrNull() as? Bundle
        if (last != null) {
            text = last.getCharSequence("text")?.toString()
            msgTime = last.getLong("time", 0L)
        }
        if (text == null) text = extras.getCharSequence(Notification.EXTRA_TEXT)?.toString()
        val msg = text ?: return
        if (msg.isBlank()) return

        val key = sbn.packageName + "|" + title
        val now = System.currentTimeMillis()

        val conv = convs.getOrPut(key) { Conv(key) }
        conv.title = title
        val action = replyAction(n)
        if (action != null) conv.action = action // se guarda para poder escribir más tarde

        // No procesar dos veces el mismo mensaje
        if (msgTime > 0) {
            if (msgTime <= (lastMsgTime[key] ?: 0L)) return
            lastMsgTime[key] = msgTime
        } else {
            if (msg == lastText[key] && now - (lastTextAt[key] ?: 0L) < 3000) return
            lastText[key] = msg
            lastTextAt[key] = now
        }

        // No responderse a sí mismo: WhatsApp vuelve a avisar con nuestro propio mensaje
        val sentAt = lastSent[key] ?: 0L
        val sentNorm = lastSentNorm[key] ?: ""
        val nMsg = norm(msg)
        val echoByTime = sentAt > 0 && (
            if (msgTime > 0) (msgTime - sentAt) in -1000L..2500L else (now - sentAt) < 2500L
        )
        val echoByText = sentNorm.isNotEmpty() && now - sentAt < 120_000L && nMsg.length >= 12 &&
            (sentNorm.contains(nMsg) || nMsg.contains(sentNorm.take(30)))
        val echoGlobal = nMsg.length >= 12 && recentSent.any { (s, t) ->
            now - t < 120_000L && s.length >= 12 && (s.contains(nMsg) || nMsg.contains(s.take(30)))
        }
        if (echoByTime || echoByText || echoGlobal) return

        // Segundos mínimos entre respuestas al mismo contacto
        if (now - sentAt < prefs.minSeconds * 1000L) return

        // Horario
        val from = prefs.hourFrom
        val to = prefs.hourTo
        if (from != to) {
            val h = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
            val ok = if (from < to) h in from until to else (h >= from || h < to)
            if (!ok) return
        }

        // Contactos excluidos / solo estos
        if (ContactList.matches(prefs.excluded, title)) return
        if (prefs.only.isNotBlank() && !ContactList.matches(prefs.only, title)) return

        val act = action ?: return

        val script = Parser.parse(prefs.script)
        val closeMs = prefs.sessionMin * 60_000L
        val prevAt = conv.lastCustomerAt
        val sinceLast = if (prevAt == 0L) Long.MAX_VALUE else now - prevAt
        conv.lastCustomerAt = now
        conv.nudged = false

        // Una persona atendió el chat: el bot se queda callado hasta que pase un buen rato
        if (conv.phase == 3) {
            if (sinceLast < closeMs) return
            conv.phase = 0
            Engine.reset(key)
        }

        // Vuelve a escribir después de que el chat se cerró (o de un rato largo de silencio)
        val returning = conv.phase == 2 ||
            (conv.phase == 0 && conv.lastBotAt > 0 && sinceLast >= closeMs) ||
            (conv.phase == 1 && sinceLast >= closeMs)
        if (conv.phase == 1 && !returning) return // espera a una persona: no insistir
        if (returning) {
            conv.phase = 1
            Engine.reset(key)
            val t = script.nodes[RETURN_ID]?.text?.takeIf { it.isNotBlank() } ?: DEFAULT_RETURN_TEXT
            send(act, prefs.decorate(t.replace("{nombre}", title)), conv, "Volvió a escribir")
            return
        }

        // Conversación normal con el menú
        val body = Engine.reply(key, title, msg, script, closeMs) ?: return
        if (Engine.isHandoff(key, script)) conv.phase = 1
        send(act, prefs.decorate(body), conv, "Respuesta")
    }

    /** Si el dueño abre o atiende el chat, el bot deja de responder a esa persona. */
    override fun onNotificationRemoved(
        sbn: StatusBarNotification,
        rankingMap: NotificationListenerService.RankingMap,
        reason: Int
    ) {
        val prefs = Prefs(this)
        if (!prefs.enabled || !prefs.pauseOnHuman) return
        if (sbn.packageName !in pkgs) return
        if (reason != NotificationListenerService.REASON_CLICK &&
            reason != NotificationListenerService.REASON_APP_CANCEL) return
        val title = sbn.notification.extras.getString(Notification.EXTRA_TITLE) ?: return
        val c = convs[sbn.packageName + "|" + title] ?: return
        if (System.currentTimeMillis() - c.lastBotAt < 15_000L) return // se canceló por nuestra respuesta
        if (c.phase == 0 || c.phase == 1) {
            c.phase = 3
            ActivityLog.add(this, "${c.title}: lo atiende una persona, el bot se pausa")
        }
    }

    /** Cada 30 segundos: recordatorio y cierre de chats sin respuesta. */
    private fun checkConvos() {
        val prefs = Prefs(this)
        if (!prefs.enabled) return
        val now = System.currentTimeMillis()
        val closeMs = prefs.sessionMin * 60_000L
        val nudgeMs = prefs.nudgeMin * 60_000L
        val script = Parser.parse(prefs.script)
        for (c in convs.values) {
            if ((c.phase != 0 && c.phase != 1) || c.lastCustomerAt == 0L) continue
            if (c.phase == 0 && c.lastBotAt == 0L) continue
            val idle = now - c.lastCustomerAt
            if (idle >= closeMs) {
                c.phase = 2
                val act = c.action
                val t = script.nodes[CLOSE_ID]?.text?.takeIf { it.isNotBlank() } ?: DEFAULT_CLOSE_TEXT
                if (act != null) send(act, prefs.decorate(t.replace("{nombre}", c.title)), c, "Cierre del chat")
                else ActivityLog.add(this, "Cierre sin enviar a ${c.title}: no hay botón de respuesta")
            } else if (c.phase == 0 && prefs.nudgeOn && !c.nudged && nudgeMs < closeMs &&
                idle >= nudgeMs && c.lastBotAt >= c.lastCustomerAt) {
                c.nudged = true
                val act = c.action ?: continue
                val t = script.nodes[NUDGE_ID]?.text?.takeIf { it.isNotBlank() } ?: DEFAULT_NUDGE_TEXT
                send(act, prefs.decorate(t.replace("{nombre}", c.title)), c, "Recordatorio")
            }
        }
    }

    private fun send(action: Notification.Action, reply: String, conv: Conv, what: String): Boolean {
        val ri = action.remoteInputs ?: return false
        val results = Bundle().apply { putCharSequence(ri[0].resultKey, reply) }
        val intent = Intent()
        RemoteInput.addResultsToIntent(ri, intent, results)
        return try {
            action.actionIntent.send(this, 0, intent)
            val t = System.currentTimeMillis()
            lastSent[conv.key] = t
            lastSentNorm[conv.key] = norm(reply)
            recentSent.add(Pair(norm(reply), t))
            recentSent.removeAll { t - it.second > 300_000L }
            conv.lastBotAt = t
            ActivityLog.add(this, "$what → ${conv.title}")
            true
        } catch (e: PendingIntent.CanceledException) {
            ActivityLog.add(this, "No pude enviar ($what) a ${conv.title}: la notificación ya no está")
            false
        }
    }
}
